#!/bin/sh
docker logs exam-client -f