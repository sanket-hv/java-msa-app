#!/bin/sh
docker logs exam-service -f